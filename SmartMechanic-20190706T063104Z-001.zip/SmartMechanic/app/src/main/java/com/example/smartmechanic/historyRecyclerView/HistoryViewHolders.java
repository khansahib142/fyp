package com.example.smartmechanic.historyRecyclerView;

import android.content.Intent;
import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.v7.widget.RecyclerView;
import android.view.View;
import android.widget.TextView;

import com.example.smartmechanic.HistorySingleActivity;
import com.example.smartmechanic.R;

public class HistoryViewHolders extends RecyclerView.ViewHolder implements View.OnClickListener {

    public TextView serviceId;
    public HistoryViewHolders(@NonNull View itemView) {
        super( itemView );
        itemView.setOnClickListener( this );

        serviceId = (TextView) itemView.findViewById( R.id.serviceId );

    }

    @Override
    public void onClick(View v) {
        Intent intent = new Intent( v.getContext(), HistorySingleActivity.class );
        Bundle b = new Bundle(  );
        b.putString( "serviceId", serviceId.getText().toString() );
        intent.putExtras( b );
        v.getContext().startActivity( intent );

    }
}
