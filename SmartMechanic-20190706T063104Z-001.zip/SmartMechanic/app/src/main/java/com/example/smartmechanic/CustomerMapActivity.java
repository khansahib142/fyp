package com.example.smartmechanic;

import android.Manifest;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.location.Location;
import android.location.LocationListener;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.support.v4.app.ActivityCompat;
import android.support.v4.app.FragmentActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.RatingBar;
import android.widget.TextView;
import android.widget.Toast;

import com.bumptech.glide.Glide;
import com.firebase.geofire.GeoFire;
import com.firebase.geofire.GeoLocation;
import com.firebase.geofire.GeoQuery;
import com.firebase.geofire.GeoQueryEventListener;
import com.google.android.gms.common.ConnectionResult;
import com.google.android.gms.common.api.Api;
import com.google.android.gms.common.api.GoogleApiClient;
import com.google.android.gms.common.api.PendingResult;
import com.google.android.gms.common.api.Status;
import com.google.android.gms.location.LocationRequest;
import com.google.android.gms.location.LocationServices;
import com.google.android.gms.maps.CameraUpdateFactory;
import com.google.android.gms.maps.GoogleMap;
import com.google.android.gms.maps.OnMapReadyCallback;
import com.google.android.gms.maps.SupportMapFragment;
import com.google.android.gms.maps.model.BitmapDescriptorFactory;
import com.google.android.gms.maps.model.LatLng;
import com.google.android.gms.maps.model.Marker;
import com.google.android.gms.maps.model.MarkerOptions;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class CustomerMapActivity extends FragmentActivity implements OnMapReadyCallback, GoogleApiClient.ConnectionCallbacks, GoogleApiClient.OnConnectionFailedListener, com.google.android.gms.location.LocationListener {

    private GoogleMap mMap;
    GoogleApiClient mGoogleApiClient;
    Location mLastLocation;
    LocationRequest mLocationRequest;

    private Button mLogout, mRequest, mSettings, mHistory;
    private LatLng myLocation;

    private Boolean requestBol = false;

    private String requestService;

    private Marker locationMarker;

    private LinearLayout mServiceProviderInfo;

    private ImageView mServiceProviderProfileImage;

    private TextView mServiceProviderName, mServiceProviderPhone, mServiceProviderService;

    private RadioGroup mRadioGroup;

    private RatingBar mRatingBar;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate( savedInstanceState );
        setContentView( R.layout.activity_customer_map );
        // Obtain the SupportMapFragment and get notified when the map is ready to be used.
        SupportMapFragment mapFragment = (SupportMapFragment) getSupportFragmentManager().findFragmentById( R.id.map );
        mapFragment.getMapAsync( this );

        if (ActivityCompat.checkSelfPermission( this, Manifest.permission.ACCESS_FINE_LOCATION ) != PackageManager.PERMISSION_GRANTED && ActivityCompat.checkSelfPermission( this, Manifest.permission.ACCESS_COARSE_LOCATION ) != PackageManager.PERMISSION_GRANTED) {

            ActivityCompat.requestPermissions( CustomerMapActivity.this, new String[] {Manifest.permission.ACCESS_FINE_LOCATION} , LOCATION_REQUEST_CODE );
        }else {
            mapFragment.getMapAsync( this );
        }

        mServiceProviderInfo = (LinearLayout) findViewById( R.id.serviceProviderInfo );

        mServiceProviderProfileImage = (ImageView) findViewById( R.id.serviceProviderProfileImage );

        mServiceProviderName = (TextView) findViewById( R.id.serviceProviderName );
        mServiceProviderPhone = (TextView) findViewById( R.id.serviceProiderPhone );
        mServiceProviderService= (TextView) findViewById( R.id.serviceProiderService);

        mRatingBar = (RatingBar) findViewById( R.id.ratingBar );

        mRadioGroup = (RadioGroup) findViewById( R.id.radioGroup );
        mRadioGroup.check( R.id.Mechanic );

        mLogout = (Button) findViewById( R.id.logout );
        mRequest = (Button) findViewById( R.id.request );
        mSettings = (Button) findViewById( R.id.settings );
        mHistory = (Button) findViewById( R.id.history );

        mLogout.setOnClickListener( new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                FirebaseAuth.getInstance().signOut();
                Intent intent = new Intent( CustomerMapActivity.this, MainActivity.class );
                startActivity( intent );
                finish();
                return;
            }
        } );

        mRequest.setOnClickListener( new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                if(requestBol){
                    endService();

                }else{
                    int selectId = mRadioGroup.getCheckedRadioButtonId();

                    final RadioButton radioButton = (RadioButton) findViewById( selectId );

                    if(radioButton.getText() == null){
                        return;
                    }

                    requestService = radioButton.getText().toString();
                    requestBol = true;
                String userId = FirebaseAuth.getInstance().getCurrentUser().getUid();

                DatabaseReference ref = FirebaseDatabase.getInstance().getReference("customerRequest");
                GeoFire geoFire = new GeoFire( ref );
                geoFire.setLocation( userId, new GeoLocation( mLastLocation.getLatitude(), mLastLocation.getLongitude() ) );

                myLocation = new LatLng( mLastLocation.getLatitude(), mLastLocation.getLongitude() );
                locationMarker = mMap.addMarker( new MarkerOptions().position( myLocation ).title( "I am Here" ) .icon( BitmapDescriptorFactory.fromResource( R.mipmap.racing ) ));

                mRequest.setText( "Getting your Smart Mechanic" );
                getClosestServiceProvider();}
            }
        } );

        mSettings.setOnClickListener( new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent( CustomerMapActivity.this, CustomerSettingsActivity.class );
                startActivity( intent );
                return;
            }
        } );

        mHistory.setOnClickListener( new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent( CustomerMapActivity.this, HistoryActivity.class );
                intent.putExtra( "customerOrServiceProvider", "Customers" );
                startActivity( intent );
                return;
            }
        } );
    }

    private int radius = 1;
    private Boolean serviceProviderFound = false;
    private String serviceProviderFoundId;
    GeoQuery geoQuery;


    private void getClosestServiceProvider(){
        DatabaseReference serviceProviderLocation = FirebaseDatabase.getInstance().getReference().child( "serviceProviderAvailable" );

        GeoFire geoFire = new GeoFire( serviceProviderLocation );

        GeoQuery geoQuery = geoFire.queryAtLocation( new GeoLocation( myLocation.latitude, myLocation.longitude), radius );
        geoQuery.removeAllListeners();

        geoQuery.addGeoQueryEventListener( new GeoQueryEventListener() {
            @Override
            public void onKeyEntered(String key, GeoLocation location) {
                if(!serviceProviderFound && requestBol){
                    DatabaseReference mCustomerDatabase = FirebaseDatabase.getInstance().getReference().child( "Users" ).child( "ServiceProvider" ).child( key );
                    mCustomerDatabase.addListenerForSingleValueEvent( new ValueEventListener() {
                        @Override
                        public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                            if(dataSnapshot.exists() && dataSnapshot.getChildrenCount()>0){
                                Map<String,Object> serviceProviderMap = (Map<String, Object>) dataSnapshot.getValue();
                                if(serviceProviderFound){
                                    return;
                                }

                                if(serviceProviderMap.get( "service" ).equals( requestService )){
                                    serviceProviderFound = true;
                                    serviceProviderFoundId = dataSnapshot.getKey();

                                    DatabaseReference serviceRef = FirebaseDatabase.getInstance().getReference().child( "Users" ).child("ServiceProvider").child( "customerRequest" );
                                    String customerId = FirebaseAuth.getInstance().getCurrentUser().getUid();
                                    HashMap map = new HashMap(  );
                                    map.put( "customerServiceId", customerId );
                                    serviceRef.updateChildren( map );

                                    getServiceProviderLocation();
                                    getServiceProviderInfo();
                                    getHasServiceEnded();
                                    mRequest.setText( "looking for service provider location....." );
                                }
                            }
                        }

                        @Override
                        public void onCancelled(@NonNull DatabaseError databaseError) {

                        }
                    } );

                }

            }

            @Override
            public void onKeyExited(String key) {

            }

            @Override
            public void onKeyMoved(String key, GeoLocation location) {

            }

            @Override
            public void onGeoQueryReady() {
                if(!serviceProviderFound){
                    radius++;
                    getClosestServiceProvider();
                }

            }

            @Override
            public void onGeoQueryError(DatabaseError error) {

            }
        } );
    }

    private Marker mServiceProviderMarker;
    private DatabaseReference serviceLocationRef;
    private ValueEventListener ServiceProviderLocationRefListener;

    private void getServiceProviderLocation(){
        serviceLocationRef = FirebaseDatabase.getInstance().getReference().child( "serviceProviderWorking" ).child(serviceProviderFoundId).child( "l" );
        ServiceProviderLocationRefListener = serviceLocationRef.addValueEventListener( new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                if(dataSnapshot.exists() && requestBol){
                    List<Object> map = (List<Object>) dataSnapshot.getValue();
                    double locationLat = 0;
                    double locationLng = 0;
                    mRequest.setText( "Smart Mechanic Found" );
                    if(map.get( 0 ) != null){
                        locationLat = Double.parseDouble( map.get( 0 ).toString() );
                    }
                    if(map.get( 1 ) != null){
                        locationLat = Double.parseDouble( map.get( 1 ).toString() );
                    }
                    LatLng serviceProviderLatLng = new LatLng( locationLat, locationLng );
                    if(mServiceProviderMarker != null){
                        mServiceProviderMarker.remove();
                    }

                    Location loc1 = new Location( "" );
                    loc1.setLatitude( myLocation.latitude );
                    loc1.setLongitude( myLocation.longitude );

                    Location loc2 = new Location( "" );
                    loc2.setLatitude( serviceProviderLatLng.latitude );
                    loc2.setLongitude( serviceProviderLatLng.longitude );

                    float distance = loc1.distanceTo( loc2 );

                    mRequest.setText( "Service provider Found: " + String.valueOf( distance ) );

                    mServiceProviderMarker = mMap.addMarker( new MarkerOptions().position( serviceProviderLatLng ).title( "your Service provider" ) .icon( BitmapDescriptorFactory.fromResource( R.mipmap.mechanic ) ));
                }
            }

            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {

            }
        } );
    }

    private void getServiceProviderInfo(){
        mServiceProviderInfo.setVisibility( View.VISIBLE );
        DatabaseReference mCustomerDatabase = FirebaseDatabase.getInstance().getReference().child( "Users" ).child( "ServiceProvider" ).child(serviceProviderFoundId);
        mCustomerDatabase.addListenerForSingleValueEvent( new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                if(dataSnapshot.exists() && dataSnapshot.getChildrenCount()>0){
                    Map<String, Object> map = (Map<String, Object>) dataSnapshot.getValue();

                    if(map.get( "name" )!=null){

                        mServiceProviderName.setText( map.get( "name" ).toString());
                    }

                    if(map.get( "phone" )!=null){

                        mServiceProviderPhone.setText( map.get( "phone" ).toString());
                    }

                    if(map.get( "service" )!=null){

                        mServiceProviderService.setText( map.get( "service" ).toString());
                    }

                    if(map.get( "profileImageUrl" )!=null){

                        Glide.with( getApplication() ).load(  map.get( "profileImageUrl" ).toString()).into( mServiceProviderProfileImage );
                    }

                    int ratingSum = 0;
                    float ratingTotal = 0;
                    float ratingAvg = 0;
                    for(DataSnapshot child : dataSnapshot.child( "rating" ).getChildren()){
                        ratingSum = ratingSum + Integer.valueOf( child.getValue().toString() );
                        ratingTotal++;
                    }
                    if(ratingTotal!=0){
                        ratingAvg = ratingSum/ratingTotal;
                        mRatingBar.setRating( ratingAvg );
                    }


                }
            }

            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {

            }
        } );
    }
    private DatabaseReference serviceHasEndedRef;
    private ValueEventListener serviceHasEndedRefListner;

    private void getHasServiceEnded(){

        serviceHasEndedRef = FirebaseDatabase.getInstance().getReference().child( "Users" ).child( "ServiceProvider" ).child( serviceProviderFoundId ).child( "customerServiceId" );
        serviceHasEndedRefListner = serviceHasEndedRef.addValueEventListener( new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                if(dataSnapshot.exists()){


                }else{
                    endService();


                }
            }

            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {

            }
        } );
    }

    private void endService(){
        requestBol = false;
        geoQuery.removeAllListeners();
        serviceLocationRef.removeEventListener( ServiceProviderLocationRefListener );
        serviceHasEndedRef.removeEventListener( serviceHasEndedRefListner );

        if(serviceProviderFoundId != null){
            DatabaseReference serviceRef = FirebaseDatabase.getInstance().getReference().child( "Users" ).child("ServiceProvider").child( serviceProviderFoundId ).child( "customerRequest" );
            serviceRef.setValue( true );
            serviceProviderFoundId = null;
        }
        serviceProviderFound = false;
        radius = 1;

        String userId = FirebaseAuth.getInstance().getCurrentUser().getUid();
        DatabaseReference ref = FirebaseDatabase.getInstance().getReference("customerRequest");
        GeoFire geoFire = new GeoFire( ref );
        geoFire.removeLocation( userId);

        if(locationMarker != null){
            locationMarker.remove();
        }
        mRequest.setText( "call Smart Mechanic" );

        mServiceProviderInfo.setVisibility( View.GONE );
        mServiceProviderName.setText( "" );
        mServiceProviderPhone.setText( "" );
        mServiceProviderService.setText( "" );
        mServiceProviderProfileImage.setImageResource( R.mipmap.adduser );


    }


    @Override
    public void onMapReady(GoogleMap googleMap) {
        mMap = googleMap;

        if (ActivityCompat.checkSelfPermission( this, Manifest.permission.ACCESS_FINE_LOCATION ) != PackageManager.PERMISSION_GRANTED && ActivityCompat.checkSelfPermission( this, Manifest.permission.ACCESS_COARSE_LOCATION ) != PackageManager.PERMISSION_GRANTED) {

            ActivityCompat.requestPermissions( CustomerMapActivity.this, new String[] {Manifest.permission.ACCESS_FINE_LOCATION} , LOCATION_REQUEST_CODE );
        }
        buildGoogleApiClient();
        mMap.setMyLocationEnabled( true );
    }

    protected synchronized void buildGoogleApiClient(){
        mGoogleApiClient = new GoogleApiClient.Builder( this )
                .addConnectionCallbacks( this )
                .addOnConnectionFailedListener( this )
                .addApi( LocationServices.API )
                .build();
        mGoogleApiClient.connect();

    }

    @Override
    public void onLocationChanged(Location location) {
        mLastLocation = location;

        LatLng latLng = new LatLng( location.getLatitude(), location.getLongitude() );

        mMap.moveCamera( CameraUpdateFactory.newLatLng( latLng ) );
        mMap.animateCamera( CameraUpdateFactory.zoomTo( 11 ) );

        String userId = FirebaseAuth.getInstance().getCurrentUser().getUid();
        DatabaseReference ref = FirebaseDatabase.getInstance().getReference("Customer is here");

        GeoFire geoFire = new GeoFire( ref );
        geoFire.setLocation( userId, new GeoLocation( location.getLatitude(), location.getLongitude() ) );

    }



    @Override
    public void onConnected(@Nullable Bundle bundle) {
        mLocationRequest = new LocationRequest();
        mLocationRequest.setInterval( 1000 );
        mLocationRequest.setFastestInterval( 1000 );
        mLocationRequest.setPriority( LocationRequest.PRIORITY_HIGH_ACCURACY );

        if (ActivityCompat.checkSelfPermission( this, Manifest.permission.ACCESS_FINE_LOCATION ) != PackageManager.PERMISSION_GRANTED && ActivityCompat.checkSelfPermission( this, Manifest.permission.ACCESS_COARSE_LOCATION ) != PackageManager.PERMISSION_GRANTED) {

            return;
        }
        LocationServices.FusedLocationApi.requestLocationUpdates( mGoogleApiClient, mLocationRequest, this );

    }

    @Override
    public void onConnectionSuspended(int i) {

    }

    @Override
    public void onConnectionFailed(@NonNull ConnectionResult connectionResult) {

    }
    final int LOCATION_REQUEST_CODE =1;



    @Override
    protected void onStop(){
        super.onStop();


    }
}
