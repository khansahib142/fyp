package com.example.smartmechanic;

import android.support.annotation.NonNull;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;

import com.example.smartmechanic.historyRecyclerView.HistoryAdapter;
import com.example.smartmechanic.historyRecyclerView.historyObject;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.util.ArrayList;
import java.util.List;

public class HistoryActivity extends AppCompatActivity {

    private String customerOrServiceProvider, userId;

    private RecyclerView mHistoryRecyclerView;
    private RecyclerView.Adapter mHsitoryAdapter;
    private RecyclerView.LayoutManager mHistoryLayoutManager;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate( savedInstanceState );
        setContentView( R.layout.activity_history );

        mHistoryRecyclerView = (RecyclerView) findViewById( R.id.historyRecyclerView );
        mHistoryRecyclerView.setNestedScrollingEnabled(false);
        mHistoryRecyclerView.setHasFixedSize( true );
        mHistoryLayoutManager = new LinearLayoutManager( HistoryActivity.this );
        mHistoryRecyclerView.setLayoutManager( mHistoryLayoutManager );
        mHsitoryAdapter = new HistoryAdapter( getDataSetHistory(), HistoryActivity.this );
        mHistoryRecyclerView.setAdapter( mHsitoryAdapter );

        customerOrServiceProvider = getIntent().getExtras().getString( "customerOrServiceProvider" );
        userId = FirebaseAuth.getInstance().getCurrentUser().getUid();
        getUserHistoryIds();


    }

    private void getUserHistoryIds() {
        DatabaseReference userHistoryDatabase = FirebaseDatabase.getInstance().getReference().child( "Users" ).child( customerOrServiceProvider ).child( userId ).child( "history" );
        userHistoryDatabase.addListenerForSingleValueEvent( new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                if(dataSnapshot.exists()){
                    for(DataSnapshot history : dataSnapshot.getChildren()){
                        FetchRideInformation(history.getKey());
                    }
                }
            }

            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {

            }
        } );
    }

    private void FetchRideInformation(String servicekey) {
        DatabaseReference historyDatabase = FirebaseDatabase.getInstance().getReference().child( "history" ).child( servicekey );
        historyDatabase.addListenerForSingleValueEvent( new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                if(dataSnapshot.exists()){
                    String serviceId = dataSnapshot.getKey();
                    historyObject obj = new historyObject( serviceId );
                    resultHistory.add( obj );

                }
            }

            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {

            }
        } );
    }

    private ArrayList resultHistory = new ArrayList<historyObject>(  );
    private ArrayList<historyObject> getDataSetHistory() {
        return resultHistory;

    }
}
