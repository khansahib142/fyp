package com.example.smartmechanic.historyRecyclerView;

public class historyObject {

    private String serviceId;

    public historyObject(String serviceId){
        this.serviceId = serviceId;
    }

    public String getServiceId(){
        return serviceId;
    }
}
