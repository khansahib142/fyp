package com.example.smartmechanic;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

public class MainActivity extends AppCompatActivity {

    private Button mServiceProvider, mCustomer;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate( savedInstanceState );
        setContentView( R.layout.activity_main );

        mServiceProvider = (Button) findViewById( R.id.serviceProvider );
        mCustomer = (Button) findViewById( R.id.customer );

        mServiceProvider.setOnClickListener( new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent( MainActivity.this, ServiceProviderLoginActivity.class );
                startActivity( intent );
                finish();
                return;
            }
        } );

        mCustomer.setOnClickListener( new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent( MainActivity.this, CustomerLoginActivity.class );
                startActivity( intent );
                finish();
                return;
            }
        } );
    }
}
